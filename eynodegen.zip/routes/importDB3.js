var express = require('express');
var router = express.Router();

const dblib = require('../lib/dblib');
const datelib = require('../lib/datelib');
const { exec } = require("child_process");
var spawn = require('child_process').spawn;



const fs = require('fs');
const path = require('path');

const connMaster = { host: 'localhost', user: 'root', password: '', database: 'admin_iaudit' };
const baseFilePath =  path.join(__dirname,'../../uploads/Clients');




router.get('/',(req,res,next) => {
    
    let sql = '';
    let dbResponse = [];

    let db3 = null;
    let fk_client_id = '';
    let db2= null;
    let list_db2_tables = [];
    let connDB3 = null;

    const fk_analysis_id =  req.query.fk_analysis_id;

    importToMySql();

    async function importToMySql(){
        
        try{
            
            sql = 'SELECT * FROM `iaudit_list_analysis` WHERE  `id` = '+fk_analysis_id; 
            dbResponse = await dblib.getData( connMaster, sql);
            db3 = dbResponse[0].db_name;
            connDB3 = { host: 'localhost', user: 'root', password: '', database: db3 };
    
            fk_client_id = dbResponse[0].fk_client_id;
            sql = 'SELECT * FROM `iaudit_clients` WHERE  `id` = '+fk_client_id; 
            dbResponse = await dblib.getData( connMaster, sql);
            db2 = dbResponse[0].client_database;

        }
        catch(error){
            //console.log(error);
        }

        const dirPath = baseFilePath+'/'+db2+'/'+db3;
        await fs.readdir(dirPath, (err, files) => {
            
            files.forEach( async (file) => {

                // Get File Extension 
                fileExt = path.extname(dirPath+'/'+file);
                //console.log(fileExt);

                if(fileExt === '.sql'){

                    listQueries = fs.readFileSync(dirPath+"/"+file).toString();

                    var result = listQueries.match(new RegExp("insert into" + '\\s(\\w+)'));
                    console.log(result);

                    return false;

                    let cmd = "mysql -u root  "+db3+" < "+dirPath+"/"+file;
					exec(cmd, (error, stdout, stderr) => {
                        if (error) {
                            console.log(`error: ${error.message}`);
                            return;
                        }
                        if (stderr) {
                            console.log(`stderr: ${stderr}`);
                            return;
                        }
                        console.log(`stdout: ${stdout}`);
                    });
                    

                    res.jsonp({"is_completed":1,"message": "Done" }); 




                } // End IF Check File Ext Sql
                else if ( fileExt === '.txt'){

                } // End IF Check File Ext Txt
                

            }); // Foreach Loop

        }); // End Block Read dir



        //let folderFiles = 

        //let listQueries = fs.readFileSync(baseFilePath+'/'+db2+'/'+db3+).toString().split(';');
        
        /* let totalQueryLength = testSql.length;

        let chunk = parseInt(( totalQueryLength / 25 )) - 1;

        console.log("Total Queries ",totalQueryLength);

        let i = 0;
       

        for ( let sql of testSql ){
            
            result = await dblib.runQuery(connDB3,sql);

            if( i % chunk == 0 ){
                console.log("Query Executed ",i);
            }

            i++;

        }  // End For Loop

        console.log("Total Query Executed ",i); */


        //res.json({"message":"Successful","totalQuery":i});


    } // End importToSql Fn

}); //

module.exports = router;
